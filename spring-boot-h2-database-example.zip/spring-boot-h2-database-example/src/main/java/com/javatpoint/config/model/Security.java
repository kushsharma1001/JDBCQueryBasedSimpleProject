package com.javatpoint.config.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Security {

	private final String url;
	private final String authMethod;
	private final List<String> roles;
	
	public Security(String url, String authMethod, List<String> roles) {
		super();
		this.url = url;
		this.authMethod = authMethod;
		this.roles = Collections.unmodifiableList(new ArrayList<String>(roles));
	}

	public String getUrl() {
		return url;
	}

	public String getAuthMethod() {
		return authMethod;
	}

	public List<String> getRoles() {
		return roles;
	}

	@Override
	public String toString() {
		return "Security [url=" + url + ", authMethod=" + authMethod + ", roles=" + roles + "]";
	}
}
