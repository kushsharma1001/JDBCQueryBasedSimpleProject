package com.javatpoint.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.context.annotation.Configuration;

import com.javatpoint.config.model.Security;

/* METHOD-1 for reading application properties
@Configuration
public class EnvConfig {

	@Value("${message}")
	private String message;
	
	@Value("${message2}")
	private String message2;
	
	@Bean
	public String getMessage() {
		return message;
	}
	
	@Bean
	public String getMessage2() {
		return message2;
	}
}
*/

/* METHOD-2 for reading application properties
@Configuration
@ConfigurationProperties
public class EnvConfig {

	private String message;
	private String message2;
	
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage2(String message2) {
		this.message2 = message2;
	}
	public String getMessage2() {
		return message2;
	}
}*/

@ConfigurationProperties //In this approach, we use @EnableConfigurationProperties annotation at SpringBootApplication class level
@ConstructorBinding
public final class EnvConfig {

	private final String message;
	private final String message2;
	private final Security security;
	private final String messageTemp;
	@Value("${message.default.app.deploy.strategy}")
	private final String defaultAppDeployStrategy;
	@Value("${message.default.app.deploy.retries:null}")
	private final String defaultAppDeployRetries;
	private final String messa;
	
	public EnvConfig(String message, String message2, Security security, String messageTemp, String defaultAppDeployStrategy, String defaultAppDeployRetries, String messa) {
		super();
		this.message = message;
		this.message2 = message2;
		this.security = new Security(security.getUrl(), security.getAuthMethod(), security.getRoles()); //this is done for immutability
		this.messageTemp = messageTemp;
		this.defaultAppDeployStrategy = defaultAppDeployStrategy;
		this.defaultAppDeployRetries = defaultAppDeployRetries;
		this.messa = messa;
	}

	public String getMessage() {
		return message;
	}
	public String getMessage2() {
		return message2;
	}
	public Security getSecurity() {
		return security;
	}
	public String getMessageTemp() {
		return messageTemp;
	}
	public String getDefaultAppDeployStrategy() {
		return defaultAppDeployStrategy;
	}
	public String getDefaultAppDeployRetries() {
		return defaultAppDeployRetries;
	}
	public String getMessa() {
		return messa; //it will not be Null but will be empty string for default profile
	}

	@Override
	public String toString() {
		return "EnvConfig [message=" + message + ", message2=" + message2 + ", security=" + security + ", messageTemp="
				+ messageTemp + ", defaultAppDeployStrategy=" + defaultAppDeployStrategy + ", defaultAppDeployRetries="
				+ defaultAppDeployRetries + ", messa={" + messa + "} ]";
	}
}