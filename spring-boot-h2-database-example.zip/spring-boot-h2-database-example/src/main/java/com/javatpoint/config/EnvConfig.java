package com.javatpoint.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.context.annotation.Configuration;

import com.javatpoint.config.model.Security;

/* METHOD-1 for reading application properties
@Configuration
public class EnvConfig {

	@Value("${app.message}")
	private String message;
	
	@Value("${app.message2}")
	private String message2;
	
	@Bean
	public String getMessage() {
		return message;
	}
	
	@Bean
	public String getMessage2() {
		return message2;
	}
}
*/

/* METHOD-2 for reading application properties
@Configuration
@ConfigurationProperties(prefix = "app")
public class EnvConfig {

	private String message;
	private String message2;
	
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage2(String message2) {
		this.message2 = message2;
	}
	public String getMessage2() {
		return message2;
	}
}*/

@ConfigurationProperties(prefix = "app") //In this approach, we use @EnableConfigurationProperties annotation at SpringBootApplication class level
@ConstructorBinding
public final class EnvConfig {

	private final String message;
	private final String message2;
	private final Security security;
	
	public EnvConfig(String message, String message2, Security security) {
		super();
		this.message = message;
		this.message2 = message2;
		this.security = new Security(security.getUrl(), security.getAuthMethod(), security.getRoles()); //this is done for immutability
	}

	public String getMessage() {
		return message;
	}
	public String getMessage2() {
		return message2;
	}
	public Security getSecurity() {
		return security;
	}

	@Override
	public String toString() {
		return "EnvConfig [message=" + message + ", message2=" + message2 + ", security=" + security + "]";
	}
	
}