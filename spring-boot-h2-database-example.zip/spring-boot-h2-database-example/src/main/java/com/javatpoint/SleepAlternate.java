package com.javatpoint;
import static org.springframework.http.HttpStatus.NOT_FOUND;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * @author I061700 on 9/22/2020
 */
import static org.springframework.http.HttpStatus.CONFLICT;
public class SleepAlternate {
	 
	public static void main(String[] args) {
		List<TenantStatus> tenantList = new ArrayList<>();
		tenantList.add(new TenantStatus("tid123", "CPI", 1, "COMPLETE"));
		tenantList.add(new TenantStatus("tid123", "ICA", 2, "COMPLETE"));
		tenantList.add(new TenantStatus("tid123", "OCN", 3, "COMPLETE"));
		tenantList.add(new TenantStatus("tid1234", "ICA", 4, "COMPLETE"));
		
		//tenantList = tenantList.stream().map(p -> p.getTenantId()).distinct().collect(Collectors.toList());
		
		Set<Object> set = ConcurrentHashMap.newKeySet();
		tenantList = tenantList.stream().filter((tenantStatus) -> {
			return set.add(tenantStatus.getTenantId());
			}).collect(Collectors.toList());
		tenantList = tenantList.stream().filter(distinctByKey((TenantStatus) -> TenantStatus.getTenantId())).collect(Collectors.toList());
		tenantList.forEach(System.out::println);
	}
	
	 private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractorFunction) {
	        //Create a set for creating distinct objects
	        Set<Object> seen = ConcurrentHashMap.newKeySet();
	        
	        // apply the function on the object to extract unique set
	        return t -> seen.add(keyExtractorFunction.apply(t));
	    }
	
  /*  public static void main(String[] args) throws ExecutionException, InterruptedException {
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        Callable<String> supplier = () -> execute("from supplier");
        ScheduledFuture<?> scheduledFuture = executorService.schedule(supplier, 10, TimeUnit.SECONDS);
        System.out.println("Printed before supplier schedule at: "+ System.currentTimeMillis());
        System.out.println(scheduledFuture.get());
        System.out.println("Printed after supplier schedule");

        scheduledFuture = executorService.schedule(runnable(), 10, TimeUnit.SECONDS);
        System.out.println("Printed before runnable schedule: "+ System.currentTimeMillis());
        scheduledFuture.get();
        System.out.println("Printed after runnable schedule");
        executorService.shutdown();
    }

    public static String execute(String testMessage) {
        return "Printed at "+ System.currentTimeMillis() + ": " + testMessage;
    }

    public static Runnable runnable() {
        return new Runnable() {
            int attempt = 0;

            public void run() {
                System.out.println("ran at "+ System.currentTimeMillis() + " run no: " + ++attempt);
            }
        };
    }

*/
}


class TenantStatus {
	
	private String tenantId;
	private String capability;
	private int id;
	private String Status;
	
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getCapability() {
		return capability;
	}
	public void setCapability(String capability) {
		this.capability = capability;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
	@Override
	public String toString() {
		return "TenantStatus [tenantId=" + tenantId + ", capability=" + capability + ", id=" + id + ", Status=" + Status
				+ "]";
	}
	
	public TenantStatus(String tenantId, String capability, int id, String status) {
		super();
		this.tenantId = tenantId;
		this.capability = capability;
		this.id = id;
		Status = status;
	}
}
