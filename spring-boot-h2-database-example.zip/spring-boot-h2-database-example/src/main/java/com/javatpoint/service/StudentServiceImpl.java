package com.javatpoint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.javatpoint.model.Student;
import com.javatpoint.repository.StudentDaoService;
@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentDaoService studentDaoService;

	@Transactional
	@Override
	public List<Student> fetchAllStudents() throws Exception {
		// TODO Auto-generated method stub
		return studentDaoService.getAllStudentsFromDb();
	}

	@Transactional
	@Override
	public Student fetchStudentById(int id) throws Exception {
		// TODO Auto-generated method stub
		
		return studentDaoService.getStudentByIdFromDb(id);
		
	}

	@Transactional
	@Override
	public void addStudent(Student student) throws Exception {
		studentDaoService.saveOrUpdateInDb(student);
	}

	@Transactional
	@Override
	public void deleteStudent(int id) throws Exception {
		studentDaoService.deleteInDb(id);
	}

}