package com.javatpoint.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.javatpoint.model.Student;

@Service
public interface StudentService {
	
	public List<Student> fetchAllStudents() throws Exception;
    public Student fetchStudentById(int id) throws Exception;
    public void addStudent(Student student) throws Exception;
    public void deleteStudent(int id) throws Exception;
}