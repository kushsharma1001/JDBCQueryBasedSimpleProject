package com.javatpoint.repository;

import java.util.List;

import com.javatpoint.model.Student;

public interface StudentDaoService {
	// getting all student records
		public List<Student> getAllStudentsFromDb() throws Exception;

		// getting a specific record
		public Student getStudentByIdFromDb(int id) throws Exception;

		public void saveOrUpdateInDb(Student student) throws Exception;

		// deleting a specific record
		public void deleteInDb(int id) throws Exception;

}
