package com.javatpoint.repository;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.javatpoint.model.Student;

@Repository
public class StudentDaoServiceImpl implements StudentDaoService{
	@Autowired
    private JdbcTemplate jdbcTemplate;

	private static final Logger log = LoggerFactory.getLogger(StudentDaoServiceImpl.class);

	@Override
	public List<Student> getAllStudentsFromDb() throws Exception {
		try {
			List<Student> students = jdbcTemplate.query("select * from student", new BeanPropertyRowMapper<>(Student.class));
			Thread.sleep(120000);
			return students;
		} catch (EmptyResultDataAccessException ee) { //remove data.sql to get empty data access exception
			log.info("Failed to get List of students from DB.");
			return null;   //throw exception to see what happens
		} catch (Exception e) {
			log.error("Exception caught in getting list from DB: {}");
			throw new Exception("Failed to get List from DB due to unknown reasons", e);
		}
	}

	@Override
	public Student getStudentByIdFromDb(int id) throws Exception {
		try {
			return jdbcTemplate.queryForObject("select * from student where id=?", new Object[] { id }, new BeanPropertyRowMapper<>(Student.class));
		}  catch (Exception e) {
			log.error("Failed to get student from DB with ID= [{}] due to unknown reasons...", id);
			throw new Exception("Failed to get student from DB with ID= " + id + " due to unknown reasons", e);
		}
	}

	@Override
	public void saveOrUpdateInDb(Student student) throws Exception {
		try {
			int count = jdbcTemplate.update("insert into student (id, name, age, email) values (?,?,?,?)", student.getId(), student.getName(), student.getAge(), student.getEmail());
			log.info("Added a student in Db. count=", count); //pass null id/name and see what happens as id and name are not null in DB
		} catch (Exception e) {
			log.error("Failed to save student [{}] into DB.", student.toString());
			throw new Exception("Failed to save student [" + student.toString() + "] into DB.", e);
		}
	}

	@Override
	public void deleteInDb(int id) throws Exception {
		try {
			int count = jdbcTemplate.update("delete from student where id=", id);
			log.info("Deleted a student with id={} from Db. count=", id, count);
			if(count!=1)
			{
				throw new SQLException();
			}
		} catch (SQLException ee) {
			log.info("Failed to delete student from DB with ID= [{}].", id);
		} catch (Exception e) {
			log.error("Failed to delete student [id={}] into DB.", id);
			throw new Exception("Failed to delete student into DB.", e);
		}
	}

}
