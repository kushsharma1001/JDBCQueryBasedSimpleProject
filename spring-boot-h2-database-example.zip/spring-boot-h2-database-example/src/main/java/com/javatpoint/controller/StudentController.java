package com.javatpoint.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.javatpoint.config.EnvConfig;
import com.javatpoint.model.Student;
import com.javatpoint.service.StudentService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "StudentController")
public class StudentController {

	@Autowired
	StudentService studentService;
	@Autowired
	EnvConfig envConfig;
	 private RestTemplate restTemplate = new RestTemplate();
	 
	private static final Logger log = LoggerFactory.getLogger(StudentController.class);
	
	@ApiOperation(value = "Get all students in DB.")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Not Authorized!"),
			@ApiResponse(code = 403, message = "Forbidden!!!"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "Success|OK") })
	@GetMapping("/student")
	private List<Student> getAllStudent() throws Exception {
		return studentService.fetchAllStudents();
	}

	@ApiOperation(value = "Get student from DB by ID.")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Not Authorized!"),
			@ApiResponse(code = 403, message = "Forbidden!!!"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "Success|OK") })
	@GetMapping("/student/{id}")
	private Student getStudent(@PathVariable("id") int id) throws Exception {
		return studentService.fetchStudentById(id);
	}

	@ApiOperation(value = "Delete student from DB having speificied ID.")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Not Authorized!"),
			@ApiResponse(code = 403, message = "Forbidden!!!"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "Success|OK") })
	@DeleteMapping("/student/{id}")
	private void deleteStudent(@PathVariable("id") int id) throws Exception {
		studentService.deleteStudent(id);
	}

	@ApiOperation(value = "Add a student in DB.")
	@ApiResponses(value = { @ApiResponse(code = 401, message = "Not Authorized!"),
			@ApiResponse(code = 403, message = "Forbidden!!!"), @ApiResponse(code = 404, message = "Not Found"),
			@ApiResponse(code = 200, message = "Success|OK") })
	@PostMapping("/student")
	private int saveStudent(@RequestBody Student student) throws Exception {
		studentService.addStudent(student);
		return student.getId();
	}
	
	@GetMapping("/getDummy")
	private String getDummy() throws Exception {
		HttpHeaders requestHeaders = new HttpHeaders();
        //requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity entity = new HttpEntity<>(requestHeaders);
		ResponseEntity<String> response = null;
		try {
		response = restTemplate.exchange("http://localhost:8080/product/dummy", HttpMethod.GET, entity, String.class);
		log.info("Response is: [{}]", response);
		log.info("Response Status is: [{}]", response.getStatusCode());
		log.info("Response Body is: [{}]", response.getBody());
		}
		catch(Exception e) {
			log.info("Response is: [{}]", response);
			log.info("Exception message... [{}]", e.getMessage());
			log.info("Exception local msgs... [{}]", e.getLocalizedMessage());
			log.info("Exception cause... [{}]", e.getCause()==null?"null":e.getCause());
			log.info("Exception cause.Msges... [{}]", e.getCause().getMessage());			
			log.info("Exception cause.localMsges... [{}]", e.getCause().getLocalizedMessage());			
			log.info("Exception stacktrace... [{}]", e.getStackTrace());
			log.info("Exception caught... [{}]", e);
			
		}
		
		return response == null? "EMPTY" : response.getBody();
	}
	
	@GetMapping("/env")
	private String getEnvMessage() {
		return envConfig.toString();
	}

	
}
