insert into student
values(1500,'One', 1500, 'jai', 'raj', '302021');

insert into student
values(1501,'Two', 1501, 'bhopal', 'mp', '34567');