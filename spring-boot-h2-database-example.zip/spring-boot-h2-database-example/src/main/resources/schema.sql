create table student
(
   id integer PRIMARY KEY,
   name varchar(255) not null,
   age integer not null,
   city varchar(255), 
   state varchar(255),
   zip varchar(10)
);